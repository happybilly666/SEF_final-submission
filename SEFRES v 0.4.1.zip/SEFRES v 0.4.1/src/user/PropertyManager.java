package user;

public class PropertyManager extends Employee
{
	public PropertyManager(String userID, String firstName, String lastName,
							String email, String address, String userType, String password)
	{
		super(userID, firstName, lastName, email, address, userType, password);
	}
}
