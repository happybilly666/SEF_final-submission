package user;

public class SaleConsultant extends Employee
{
	public SaleConsultant(String userID, String firstName, String lastName, String email, 
						String address, String userType, String password)
	{
		super(userID, firstName, lastName, email, address, userType, password);
	}
		
}